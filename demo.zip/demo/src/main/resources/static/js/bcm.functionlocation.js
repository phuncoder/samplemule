
function calculateCapitalLossSubTotal (iteration) {
	
	var factor = 0;
	var text = $('#repeatimpact'+iteration).find('option:selected').text();
	var costimpact = $('#costofimpact' + iteration).val();
	if (text == "Weekly") {
		factor = 4;
	}
	else if (text == "Once-off" || text == "Monthly") {
		factor = 1;
	}
	else if (text == "Daily") {
		factor = 30;
	}
	
	if (!isNaN(costimpact)) {
		$('#costofimpact' + iteration).val(Number(costimpact).toFixed(2));
	} else {
		$('#costofimpact' + iteration).val("0.00");
	}

	var totalcost = Number(factor*costimpact);
	if (!isNaN(factor*costimpact)) {
	    if(totalcost != 0) {
			$('#costTotal' + iteration).val(totalcost.toFixed(2));						
			$('#hiddencostTotal' + iteration).val(totalcost.toFixed(2));						
		} else {
			$('#costTotal' + iteration).val("");
			$('#hiddencostTotal' + iteration).val("");
		}
	} else {
		$('#costTotal' + iteration).val("");
		$('#hiddencostTotal' + iteration).val("");
	}
}

function calculateCapitalLossTotal() {
	
	var totalcost = 0;
	$('.costimpactentrycount').each(function(index) {
		var iteration = Number(index) + 1;
		var entrytotalCost  = $('#costTotal' + iteration).val();
		if (!isNaN(entrytotalCost)) {
			totalcost  = Number(entrytotalCost) + totalcost;
		} 
	});
	
	if (totalcost != 0 ) {
		$('#totaliser').val(Number(totalcost).toFixed(2));            
		$('#hiddentotaliser').val(Number(totalcost).toFixed(2));
	}
	else {
		$('#totaliser').val("");            
		$('#hiddentotaliser').val("");
	}
}

function validatefinancialimpactform() {

	var isValid =  $('#financialform').valid();
	return isValid;
}

function validatefunctionlocationform()  {
	var isValid =  $('#functionForm').valid();
	return isValid;
	
}
function showhidedropdown(element, show) {
	
	var hidden = element.parent().is('span');
	if (show) {
		if (hidden) {
			element.unwrap().show();
		}
	} else {
		if (!hidden) {
			element.wrap('<span>').hide();
		}	
	}
}

function dynamicshowhidedropdown(entryselector, selectselector, optionlistselector, lastText) {
	
	var otherid = $(selectselector + "1 option:contains('" + lastText + "')").first().val();
	var periodlength = $(entryselector).length;
	var noneid =  $(selectselector + "1 option:contains('N/A')").first().val();
	var firstindicator = 1;
	
	
	
	var selectedoptions = [];
	for (var iteration = periodlength  ; iteration >= 1 ; iteration--) {
		var selectedvalue = $(selectselector +  iteration).val();
		if(selectedvalue != 0) {
			selectedoptions[selectedoptions.length] = selectedvalue; 
		}
	}
				
	for (var iteration = 1 ; periodlength >= iteration ; iteration++) {
		$(optionlistselector + iteration).each(function() {
			showhidedropdown($(this),true);
		});	
				
		
						
		var currentselectedvalue = $(selectselector  + iteration).val();			
		var optionsizes = selectedoptions.length;		
		for (var optindex = 1 ; optionsizes >= optindex ; optindex++) {
			if (selectedoptions[optindex-1] != currentselectedvalue) {	
				
				var obj = $(selectselector +  iteration + " option[value='"+ selectedoptions[optindex-1] + "']");
				showhidedropdown(obj, false);
			}
			
		}
		if (iteration == periodlength) {
			var obj = $(selectselector +  iteration + " option[value='"+otherid+"']");
			showhidedropdown(obj, true);
		} else {
			var obj = $(selectselector + iteration + " option[value='"+otherid+"']");
			showhidedropdown(obj, false);
		}
		
		if ($(selectselector +  firstindicator).val() != noneid && $(selectselector +  firstindicator).val() != 0) {	
			for (var indicator = 2 ; 5 >= indicator ; indicator++) {
				var obj = $(selectselector + indicator + " option[value='"+noneid+"']");				
				showhidedropdown(obj, false);
			}				
		}
		
		if (periodlength > 1){
			var obj = $(selectselector + firstindicator + " option[value='"+noneid+"']");
			showhidedropdown(obj, false);
		}else{
			var obj = $(selectselector + firstindicator + " option[value='"+noneid+"']");
			showhidedropdown(obj, true);
		}
		
		
	}	
}

function hideplusifLastRow(pclass, pselect, plusiconselector, pText) {

	var length = $(pclass).length;
	var text = $(pselect +""+ length.toString).find("option:selected").text()
	if (text == "Other") {
		$(plusiconselector +""+ length.toString()).hide();
	}
}