
$(function() {
	
	var resetButton = false;
	
	$('.buttontolink, .submitcontactbutton' ).click( function() {
		$(window).unbind('beforeunload');
	});
	
	$(window).bind('beforeunload', function(e) {
		var saved = $('#saved').val();
		if (saved == "false" && !resetButton) {
			 return "You have unsaved changes on this screen. Are you sure you want to leave this screen?" ;
	    }
	}); 

	$('select, input, textarea').change(function() {
		toggleSave();
	});

	$('#clashmessage').dialog({
		  resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons : {
	    	  "OK" : function() {
	    		  $(this).dialog("close");
	    	  }
	      }
	});
	
	$( "#dialogsave" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("save");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
	          	$(this).dialog( "close" );
	        	$(window).bind('beforeunload', function(e) {
	        		var saved = $('#saved').val();
	        		if (saved == "false") {
	        			return "You have unsaved changes on this screen. Are you sure you want to leave this screen?" ;
	        	    }
	        	}); 
	        }
	      }
	    });
	
	
	$( "#dialognext" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("next");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("nextwithoutsave");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	    		 $(this).dialog( "close" );
	        }
	      }
	    });
	
	$( "#partnerdialogsave" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("save");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
	          	$(this).dialog( "close" );
	        	$(window).bind('beforeunload', function(e) {
	        		var saved = $('#saved').val();
	        		if (saved == "false") {
	        			return "You have unsaved changes on this screen. Are you sure you want to leave this screen?" ;
	        	    }
	        	}); 
	        }
	      }
	   });
	
	$( "#partnerdialognext" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("next");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("nextwithoutsave");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	    		 $(this).dialog( "close" );
	        }
	      }
	    });
	
	$( "#partnerbcpdialogsave" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("save");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
	          	$(this).dialog( "close" );
	        	$(window).bind('beforeunload', function(e) {
	        		var saved = $('#saved').val();
	        		if (saved == "false") {
	        			return "You have unsaved changes on this screen. Are you sure you want to leave this screen?" ;
	        	    }
	        	}); 
	        }
	      }
	   });
	
	$( "#partnerbcpdialognext" ).dialog({
	      resizable: false,
	      autoOpen: false,
	      height: 190,
	      width : 420,
	      modal: true,
	      buttons: {
		     "Yes": function() {
	            $(this).dialog( "close" );
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("next");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	          },
	    	  "No": function() {
				 var input = $("<input/>").attr("type","hidden").attr("name","action").val("nextwithoutsave");
				 $("#wizardstepform").append($(input));
				 $('#wizardstepform').submit();
	    		 $(this).dialog( "close" );
	        }
	      }
	    });

	$('.financebutton').click(function(event) {
		$(window).unbind('beforeunload');
		
		var buttonid = this.id;
		var critical = 0;
		var cnumber = 0;
		var lastmodifiedpage = $('#lastmodifieddatetime').val();
		var functionid       = $('#functionid').val();
		var iscriticalform    = isCritical($('#criticalstate').val());
		var criticalpage     = $('#criticalpage').val();

		$('.criticalchoice').each(function(){
			if ($(this).find("option:selected").text() == "Yes") {
				critical = 1;
				return false;
			}
		});
		var date = new Date();
		var url = '/bcm/GetLatestModifiedTime?functionId=' + functionid + "&time=" + date.getTime();
		$.getJSON(url)
		   .done(function (data) {
		   	$.each(data, function () {
				if (critical == 0) {
		   			var cnumber = this.critical;
					var compareTo = 2;
					var windowlocation = window.location.href;
					if (windowlocation.indexOf("NonFinancialImpacts") > -1) {
						compareTo = 1;
					}
					if (cnumber == compareTo) {
						if (buttonid=="savebutton") {
							$( "#dialogsave" ).dialog("open");
							$("div#dialogsave").dialog ().prev().find(".ui-dialog-titlebar-close").hide();
						} else {
							$( "#dialognext" ).dialog("open");
							$("div#dialognext").dialog().prev().find(".ui-dialog-titlebar-close").hide();
						}
					} else {
			    		checkifalreadyupdated(this, buttonid, lastmodifiedpage, criticalpage, iscriticalform);
					}
				} else {
		    		checkifalreadyupdated(this, buttonid, lastmodifiedpage, criticalpage, iscriticalform);
				}
		   	});
		  })
		  .fail(function (jqxhr, textStatus, error) {
		   	console.log("###### ERROR:" + error);
		   	console.log("###### ERROR1:" + jqxhr);
		    console.log("###### ERROR2:" + textStatus);
		   });	
	});


	$('.submitbutton').click(function(event) {
		$(window).unbind('beforeunload');
		var buttonid = this.id;
		var lastmodifiedpage = $('#lastmodifieddatetime').val();
		var functionid       = $('#functionid').val();
		var criticalpage     = $('#criticalpage').val();
		var iscriticalform    = isCritical($('#criticalstate').val());
		var buttonid  = this.id;
		var currentpartner = $('#partneredstate').val();
		var newpartner = $('#fTypesearchfield').find(":selected").text();
		var currentpartnerbcp = $('#partneredBCPstate').val();
		var newpartnerbcp = $('#partneringBCPArrangements').find(":selected").text();
		
		if (currentpartner == "0" && newpartner == "Partnered" && functionid != 0) {
			if (buttonid == "savebutton") {
				$( "#partnerdialogsave" ).dialog("open");
				$("div#partnerdialogsave").dialog().prev().find(".ui-dialog-titlebar-close").hide();
			} else {
				$( "#partnerdialognext" ).dialog("open");
				$("div#partnerdialognext").dialog().prev().find(".ui-dialog-titlebar-close").hide();
			}
		} else if (currentpartnerbcp == "1" && newpartnerbcp == "No") {
			if (buttonid == "savebutton") {
				$( "#partnerbcpdialogsave" ).dialog("open");
				$("div#partnerbcpdialogsave").dialog().prev().find(".ui-dialog-titlebar-close").hide();
			} else {
				$( "#partnerbcpdialognext" ).dialog("open");
				$("div#partnerbcpdialognext").dialog().prev().find(".ui-dialog-titlebar-close").hide();
			}
		} else {
			if (functionid == 0) {
				submitform(buttonid);
			} else {
				var date = new Date();
				var url = '/bcm/GetLatestModifiedTime?functionId=' + functionid + "&time=" + date.getTime();
				var lastmodifieddatabase  = "";
				var criticaldatabase      = "";
				$.getJSON(url)
			    .done(function (data) {
			    	$.each(data, function () {    	
			    		checkifalreadyupdated(this, buttonid, lastmodifiedpage, criticalpage, iscriticalform);
			    	});	
			    })
			}
		}
	});

	$('button:contains(Reset)').click(function() {
		resetButton = true;
		toggleSave();
	});
	
	function isCritical(criticalstate) {
		var iscritical = true;
		if (criticalstate == 0) {
			iscritical = false;
		}
		return iscritical;
	}
	
	function showClashMessage(response) {
    	$('#clashmessage').html('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span> Update failed -' 
	        + response.firstname + ' ' + response.lastname + ' ' + '(' + response.lastmodifiedby + ') at ' + response.lastmodifieddate + ' ,' 
	        + ' has made a more recent change to this business function. Please click the relevant navigation bar item to refresh the details.</p>');
    	$("#clashmessage").dialog("open");
	}
	
	function toggleSave() {
		$('#saved').val(false);
		$('#savebutton').removeAttr('disabled');
	}
	
	function submitform(buttonidn) {
		var action = "next";
		if (buttonidn == "savebutton") {
			action = "save";
		} 
		var input = $("<input/>").attr("type","hidden").attr("name","action").val(action);
		 $("#wizardstepform").append($(input));
		 $('#wizardstepform').submit();
	}
	
	function checkifalreadyupdated(data, buttonid, lastmodifiedpage, criticalpage, iscriticalform) {
		var lastmodifieddatabase  = data.lastmodifieddate;
		var criticaldatabase      = isCritical(data.critical);;
		if (lastmodifieddatabase == "" || lastmodifiedpage == lastmodifieddatabase) {
			if (criticaldatabase != iscriticalform) {
				showClashMessage(data);
			} else {
				if (criticalpage == null ) {
					submitform(buttonid);							
				} else {
					if (criticalpage == criticaldatabase.toString()) {
						submitform(buttonid);							
					} else {
						showClashMessage(data);
					}
				}
			}
		} else {
			showClashMessage(data);
		}
	}
	
});

	  