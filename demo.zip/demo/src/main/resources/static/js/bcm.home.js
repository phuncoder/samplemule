

$('.buildnumber').click(
		function() {
			var select = this.id;
			$('#'+ this.id).tooltipster({
				delay : 0,
				position: 'top',
				interactive : true,				
				trigger : 'click',				
				content: 'Loading...',
			    functionBefore: function(origin, continueTooltip) {
			        continueTooltip();
			        var url = '/dashboard/GetBuildNumber?pipeline=' + select;
			        $.getJSON(url)
			    	    .done(function (data) {
			    	    	$.each(data, function () {
				    	    	origin.tooltipster('content', this.comment);
			    	    	});
			    	    })
			    	    .fail(function (jqxhr, textStatus, error) {
			    	    	console.log("###### ERROR:" + error);
			    	    	console.log("###### ERROR:" + jqxhr);
			    	    	console.log("###### ERROR:" + textStatus);
			    	    });
			    }
			});
			
		}
);		