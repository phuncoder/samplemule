$(function() {
	
	$('select, input, textarea').change(function() {
		toggleSave();
	});
	
	function toggleSave() {
		$('#saved').val(false);
		$('#savebutton').removeAttr('disabled');
	}

	var resetButton = false;
	
	$('.buttontolink, .submitbutton' ).click( function() {
		$(window).unbind('beforeunload');
	});
	
	$(window).bind('beforeunload', function(e) {
		var saved = $('#saved').val();
		if (saved == "false" && !resetButton) {
			 return "You have unsaved changes on this screen. Are you sure you want to leave this screen?" ;
	    }
	}); 
});

	  