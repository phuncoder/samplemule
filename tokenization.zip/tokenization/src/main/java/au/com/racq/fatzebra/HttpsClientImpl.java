package au.com.racq.fatzebra;

import com.sun.org.apache.xml.internal.security.utils.Base64;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.SecureRandom;


public class HttpsClientImpl {

    private String username;
    private String password;

    public HttpsClientImpl(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public <T,U> U post(URL url, T request, Class<U> clazz) {

        try {
            SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null,null, new SecureRandom());

            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setSSLSocketFactory(sslContext.getSocketFactory());
            String userCredentials = String.format("%s:%s",username, password);

            String basicAuth =  "Basic " + Base64.encode(userCredentials.getBytes());
            basicAuth = basicAuth.replaceAll("\n","");

            connection.setRequestProperty ("Authorization", basicAuth);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoInput(true);
            connection.setDoOutput(true);

            ObjectMapper_RCQ objectMapperRcq = new ObjectMapper_RCQ();
            String requestAsString = objectMapperRcq.serializer(request);

            OutputStream os = connection.getOutputStream();
            byte[] input = requestAsString.getBytes("utf-8");
            os.write(input, 0, input.length);
            StringBuilder builder = new StringBuilder();
            BufferedReader br = new BufferedReader( new InputStreamReader(connection.getInputStream(), "utf-8"));
            String responseLine  = br.readLine();
            while (responseLine != null) {
                builder.append(responseLine);
                responseLine  = br.readLine();
            }
            br.close();
            return (U) objectMapperRcq.deserializer(builder.toString(),clazz);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }




}
