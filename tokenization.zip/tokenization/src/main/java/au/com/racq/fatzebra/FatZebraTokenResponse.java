package au.com.racq.fatzebra;

public class FatZebraTokenResponse {

    private String token;
    private String cardHolderName;
    private String cardNumber;
    private String cardExpiry;
    private String cardType;
    private String cardCategory;
    private String cardSubCategory;
    private String cardIssuer;
    private String cardCountry;
    private Boolean authorised;
    private int  transactionCount;
    private String alias;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardExpiry() {
        return cardExpiry;
    }

    public void setCardExpiry(String cardExpiry) {
        this.cardExpiry = cardExpiry;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardCategory() {
        return cardCategory;
    }

    public void setCardCategory(String cardCategory) {
        this.cardCategory = cardCategory;
    }

    public String getCardSubCategory() {
        return cardSubCategory;
    }

    public void setCardSubCategory(String cardSubCategory) {
        this.cardSubCategory = cardSubCategory;
    }

    public String getCardIssuer() {
        return cardIssuer;
    }

    public void setCardIssuer(String cardIssuer) {
        this.cardIssuer = cardIssuer;
    }

    public String getCardCountry() {
        return cardCountry;
    }

    public void setCardCountry(String cardCountry) {
        this.cardCountry = cardCountry;
    }

    public Boolean getAuthorised() {
        return authorised;
    }

    public void setAuthorised(Boolean authorised) {
        this.authorised = authorised;
    }

    public int getTransactionCount() {
        return transactionCount;
    }

    public void setTransactionCount(int transactionCount) {
        this.transactionCount = transactionCount;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}
