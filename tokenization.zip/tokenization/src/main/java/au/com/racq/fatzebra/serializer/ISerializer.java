package au.com.racq.fatzebra.serializer;

public interface ISerializer<T> {

    String serialize(T request );


}
