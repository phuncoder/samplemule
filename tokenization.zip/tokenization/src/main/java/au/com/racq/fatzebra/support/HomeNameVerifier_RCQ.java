package au.com.racq.fatzebra.support;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

public class HomeNameVerifier_RCQ implements HostnameVerifier {

    public boolean verify(String s, SSLSession sslSession) {
        return true;
    }
}
