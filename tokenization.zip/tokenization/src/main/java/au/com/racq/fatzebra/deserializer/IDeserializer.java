package au.com.racq.fatzebra.deserializer;

public interface IDeserializer<T> {

    T deserialiser(String response);

}
