package au.com.racq.fatzebra;


import au.com.racq.fatzebra.annontation.Deserializer_RCQ;
import au.com.racq.fatzebra.deserializer.FatZebraResponseDeserializer;

import java.util.ArrayList;
import java.util.List;

@Deserializer_RCQ(className = FatZebraResponseDeserializer.class)
public class FatZebraResponse {

    private boolean successful;
    private FatZebraTokenResponse fatZebraTokenResponse;
    private List<String>  errors = new ArrayList<String>();
    private Boolean test;


    public boolean isSuccessful() {
        return successful;
    }

    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    public FatZebraTokenResponse getFatZebraTokenResponse() {
        return fatZebraTokenResponse;
    }

    public void setFatZebraTokenResponse(FatZebraTokenResponse fatZebraTokenResponse) {
        this.fatZebraTokenResponse = fatZebraTokenResponse;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public Boolean getTest() {
        return test;
    }

    public void setTest(Boolean test) {
        this.test = test;
    }
}
