package au.com.racq.fatzebra.deserializer;

import au.com.racq.fatzebra.FatZebraResponse;
import au.com.racq.fatzebra.FatZebraTokenResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FatZebraResponseDeserializer extends AbstractDeserializer
                                     implements IDeserializer<FatZebraResponse>  {

    public FatZebraResponseDeserializer() {

    }

    public FatZebraResponse deserialiser(String response) {

        JSONObject jsonRoot = new JSONObject(response);

        FatZebraResponse fatZebraResponse = new FatZebraResponse();
        fatZebraResponse.setSuccessful(jsonRoot.getBoolean("successful"));
        fatZebraResponse.setTest(jsonRoot.getBoolean("test"));
        JSONObject jsonResponse = jsonRoot.getJSONObject("response");
        if (jsonResponse != null) {

            FatZebraTokenResponse fatZebraTokenResponse = new FatZebraTokenResponse();
            fatZebraTokenResponse.setToken(populateField(jsonResponse,"token"));
            fatZebraTokenResponse.setCardHolderName(populateField(jsonResponse, "card_holder"));
            fatZebraTokenResponse.setCardNumber(populateField(jsonResponse, "card_number"));
            fatZebraTokenResponse.setCardExpiry(populateField(jsonResponse, "card_expiry"));
            fatZebraTokenResponse.setCardType(populateField(jsonResponse, "card_type"));
            fatZebraTokenResponse.setCardCategory(populateField(jsonResponse, "card_category"));
            fatZebraTokenResponse.setCardSubCategory(populateField(jsonResponse, "card_subcategory"));
            fatZebraTokenResponse.setCardIssuer(populateField(jsonResponse, "card_issuer"));
            fatZebraTokenResponse.setCardCountry(populateField(jsonResponse, "card_country"));
            fatZebraTokenResponse.setAuthorised(populateFieldBoolean(jsonResponse, "authorized"));
            fatZebraTokenResponse.setTransactionCount(populateFieldInt(jsonResponse, "transaction_count"));
            fatZebraTokenResponse.setAlias(populateField(jsonResponse, "alias"));
            fatZebraResponse.setFatZebraTokenResponse(fatZebraTokenResponse);

        }

        if (jsonRoot.isNull("error")) {
            JSONArray jsonErrorResponse = jsonRoot.getJSONArray("errors");
            int count = 0;
            List<String> errors = new ArrayList<String>();
            while (count < jsonErrorResponse.length()) {
                errors.add((String) jsonErrorResponse.get(count));
                count++;
            }
            fatZebraResponse.setErrors(errors);
        }
        return  fatZebraResponse;
    }
}
