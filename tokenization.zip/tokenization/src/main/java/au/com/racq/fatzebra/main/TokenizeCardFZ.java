package au.com.racq.fatzebra.main;

import au.com.racq.fatzebra.FatZebraRequest;
import au.com.racq.fatzebra.FatZebraResponse;
import au.com.racq.fatzebra.HttpsClientImpl;

import java.io.*;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;

public class TokenizeCardFZ {

    public static void main(String[] args)  {

        try {

            Date date = new Date();
            int current_Year = date.getYear() + 1900;
            int current_Month = date.getMonth() + 1;

            TokenizeCardFZ tokenizeCardFZ = new TokenizeCardFZ();

            HashMap<String,String> config = tokenizeCardFZ.readFile(new File(args[1]));

            URL url = new URL(config.get("url"));

            HttpsClientImpl httpsClient = new HttpsClientImpl(config.get("username"), config.get("password"));

            BufferedReader br = new BufferedReader(new FileReader(new File(args[0])));
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File(args[0]+ ".tokenized")));
            String inputLine = br.readLine();
            while (inputLine != null) {
                if (inputLine.trim().length() <= 0) {
                    continue;
                }
                String[] record = inputLine.split(",");
                FatZebraRequest fatZebraRequest = new FatZebraRequest();
                if (record[4].trim().equalsIgnoreCase("American Express")) {
                    fatZebraRequest.setCvv("1234");
                } else {
                    fatZebraRequest.setCvv("123");
                }

                int year = Integer.parseInt(record[3]);
                int month = Integer.parseInt(record[2]);
                if (year > current_Year) {
                    fatZebraRequest.setCardExpiry(String.format("%s/%s",record[2],record[3]));
                } else {
                    if ( year == current_Year) {
                        if (month >= current_Month) {
                            fatZebraRequest.setCardExpiry(String.format("%s/%s",record[2],record[3]));
                        } else {
                            fatZebraRequest.setCardExpiry(String.format("%s/%s",current_Month,current_Year));
                        }
                    } else {
                        fatZebraRequest.setCardExpiry(String.format("%s/%s",current_Month,current_Year));
                    }
                }


                fatZebraRequest.setCardNumber(record[1]);
                if (record.length > 5) {
                    fatZebraRequest.setCardHolderName(record[5]);
                } else {
                    fatZebraRequest.setCardHolderName("Anonymous");
                }

                System.err.println( "Tokenizing record with publicId : " + record[0]);
                try {
                    FatZebraResponse fatZebraResponse = httpsClient.post(url, fatZebraRequest, FatZebraResponse.class);
                    if (fatZebraResponse.isSuccessful()) {
                        bw.write(String.format("%s,%s,%s,%s,%s,%s,%s",record[0],record[5],
                                fatZebraResponse.getFatZebraTokenResponse().getCardNumber(),
                                record[2],record[3], record[4], fatZebraResponse.getFatZebraTokenResponse().getToken()));
                        bw.newLine();
                    } else {
                        System.err.println("..... Error tokenising public id : " + record[0]);
                    }
                } catch (Exception e) {
                    System.err.println("..... Error tokenising public id : " + record[0]);
                }
                inputLine = br.readLine();
            }
            br.close();
            bw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public HashMap<String,String> readFile(File file) {

        HashMap<String,String> config = new HashMap<String, String>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            while (line != null) {
                if (line.trim().length() <= 0) {
                    continue;
                }
                String[] values = line.split("=");
                config.put(values[0].trim(), values[1].trim());
                line = br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return config;
    }


}
