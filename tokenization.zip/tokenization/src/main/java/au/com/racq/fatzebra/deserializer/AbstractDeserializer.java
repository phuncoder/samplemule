package au.com.racq.fatzebra.deserializer;

import org.json.JSONObject;

public class AbstractDeserializer {

    protected String populateField(JSONObject node, String fieldName) {

        return (!node.isNull(fieldName)) ? node.getString(fieldName) : null;

    }

    protected Boolean populateFieldBoolean(JSONObject node, String fieldName) {

        return (!node.isNull(fieldName)) ? node.getBoolean(fieldName) : Boolean.FALSE;

    }

    protected int populateFieldInt(JSONObject node, String fieldName) {

        return (!node.isNull(fieldName)) ? node.getInt(fieldName) : 0;

    }
}
