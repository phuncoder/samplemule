package au.com.racq.fatzebra;

import au.com.racq.fatzebra.annontation.Deserializer_RCQ;
import au.com.racq.fatzebra.annontation.Serializer_RCQ;
import au.com.racq.fatzebra.deserializer.IDeserializer;
import au.com.racq.fatzebra.serializer.ISerializer;

public class ObjectMapper_RCQ {

    public <T> T deserializer(String response, Class<T> deserialized ) {

        if (deserialized.isAnnotationPresent(Deserializer_RCQ.class)){
            Deserializer_RCQ deserializer_rcq = deserialized.getAnnotation(Deserializer_RCQ.class);
            try {
                IDeserializer deserializerInstance = (IDeserializer) deserializer_rcq.className().newInstance();
                return (T) deserializerInstance.deserialiser(response);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public <T> String serializer(T request) {

        if (request.getClass().isAnnotationPresent(Serializer_RCQ.class)) {
            Serializer_RCQ serializer_rcq = request.getClass().getAnnotation(Serializer_RCQ.class);
            try {
                ISerializer serializer = (ISerializer) serializer_rcq.className().newInstance();
                return serializer.serialize(request);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }

        }
        return null;
    }
}
