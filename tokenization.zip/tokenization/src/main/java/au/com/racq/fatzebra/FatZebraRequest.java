package au.com.racq.fatzebra;

import au.com.racq.fatzebra.annontation.Serializer_RCQ;
import au.com.racq.fatzebra.serializer.FatZebraRequestSerializer;

@Serializer_RCQ(className = FatZebraRequestSerializer.class)
public class FatZebraRequest {

    private String cardNumber;
    private String cardHolderName;
    private String cardExpiry;
    private String cvv;

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getCardExpiry() {
        return cardExpiry;
    }

    public void setCardExpiry(String cardExpiry) {
        this.cardExpiry = cardExpiry;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }
}
