package au.com.racq.fatzebra.serializer;

import au.com.racq.fatzebra.FatZebraRequest;
import org.json.JSONObject;

public class FatZebraRequestSerializer implements ISerializer<FatZebraRequest>{

    public String serialize(FatZebraRequest request) {

         JSONObject jsonObject = new JSONObject();

        jsonObject.put("card_number", request.getCardNumber());
        jsonObject.put("card_holder", request.getCardHolderName());
        jsonObject.put("card_expiry", request.getCardExpiry());
        jsonObject.put("cvv", request.getCvv());

        return jsonObject.toString();

    }
}
